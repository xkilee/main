<?php 
header('Location: /public/home');
?>