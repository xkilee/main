WhatsApp Gateway M Pedia
WhatsApp Gateway M Pedia is a project created to help users send messages via WhatsApp more easily and efficiently. This project has been licensed for general use and can be used for various purposes.

The main features of this project are as follows:

Multi-device: Can be used on multiple devices at the same time for ease of use.
Text, media, button, template, and list messages: This project allows users to send various types of messages via WhatsApp, including text, media, buttons, templates, and message lists.
Campaign: Users can easily create message campaigns and send them to a number of contacts.
Autoreply: This project is also equipped with an autoreply feature that allows users to create automatic messages as replies to messages received.

Documentation : https://docwa.m-pedia.my.id
support & help : 6282298859671 | ilmansunannudin2@gmail.com